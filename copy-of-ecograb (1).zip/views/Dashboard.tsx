import React, { useState } from 'react';
import { User, Task } from '../types';
import { CheckCircle2, Circle, Flame, Calendar, ArrowRight, Leaf } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  user: User;
  addPoints: (amount: number) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, addPoints }) => {
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', title: 'Recycle 3 plastic bottles', description: 'Upload a photo of you recycling.', points: 50, completed: false, type: 'daily' },
    { id: '2', title: 'Plant a seed', description: 'Start your own garden.', points: 100, completed: false, type: 'league' },
    { id: '3', title: 'Use a reusable bag', description: 'Avoid plastic bags today.', points: 30, completed: false, type: 'daily' },
    { id: '4', title: 'Watch Eco-Doc', description: 'Learn about marine life.', points: 20, completed: false, type: 'daily' },
    { id: '5', title: 'Compost Leftovers', description: 'Dispose of food waste properly.', points: 40, completed: false, type: 'daily' },
  ]);

  const completeTask = (id: string, points: number) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: true } : t));
    addPoints(points);
  };

  // Dynamic Rank Logic
  const getRankInfo = (points: number) => {
    if (points < 100) return { title: 'Seedling', min: 0, max: 100, next: 'Sprout' };
    if (points < 250) return { title: 'Sprout', min: 100, max: 250, next: 'Sapling' };
    if (points < 500) return { title: 'Sapling', min: 250, max: 500, next: 'Tree' };
    if (points < 1000) return { title: 'Tree', min: 500, max: 1000, next: 'Forest' };
    return { title: 'Guardian', min: 1000, max: 5000, next: 'Hero' };
  };

  const rankInfo = getRankInfo(user.points);
  const progress = user.points - rankInfo.min;
  const goal = rankInfo.max - rankInfo.min;
  
  // Prevent division by zero if max point reached
  const percentage = Math.min(100, Math.floor((progress / goal) * 100));
  
  // League Data for Chart
  const data = [
    { name: 'Completed', value: Math.max(1, progress) }, // Ensure at least tiny slice visible
    { name: 'Remaining', value: Math.max(0, goal - progress) }, 
  ];
  const COLORS = ['#ffffff', 'rgba(255,255,255,0.2)'];

  return (
    <div className="p-0 space-y-6 animate-fade-in">
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* League Banner */}
        <div className="bg-gradient-to-r from-teal-500 to-green-600 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden flex flex-col justify-between min-h-[220px]">
            <div className="absolute top-0 right-0 p-4 opacity-10">
            <Calendar size={180} />
            </div>
            
            <div className="relative z-10">
            <div className="flex justify-between items-start">
                <div>
                    <h2 className="text-sm font-bold uppercase tracking-wider opacity-80 mb-1 flex items-center gap-1"><Leaf size={14}/> Current League</h2>
                    <h1 className="text-4xl font-black mb-2 tracking-tight">Ocean Guardians</h1>
                    <p className="text-teal-100 text-sm font-medium bg-teal-800/30 inline-block px-3 py-1 rounded-full backdrop-blur-sm">
                        Resets in 12 days
                    </p>
                </div>
                <div className="w-20 h-20 relative bg-white/10 rounded-full p-1 backdrop-blur-md hidden sm:block">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                        <Pie
                            data={data}
                            innerRadius={28}
                            outerRadius={38}
                            paddingAngle={0}
                            dataKey="value"
                            stroke="none"
                        >
                            {data.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex items-center justify-center text-xs font-bold">
                        {percentage}%
                    </div>
                </div>
            </div>
            </div>

            <div className="relative z-10 mt-6 bg-white/10 p-4 rounded-xl backdrop-blur-sm border border-white/10 flex items-center justify-between">
                <div>
                    <p className="text-xs uppercase font-bold text-teal-100">Current Rank</p>
                    <p className="font-bold text-xl">{rankInfo.title}</p>
                </div>
                <div className="text-right">
                    <p className="text-xs text-teal-100">Next: {rankInfo.next}</p>
                    <p className="font-bold text-xl">{rankInfo.max - user.points} pts</p>
                </div>
            </div>
        </div>

        {/* Monthly Theme Tasks */}
        <div className="bg-blue-600 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden min-h-[220px]">
            <div className="absolute -right-10 -bottom-10 opacity-20 rotate-12">
                <ArrowRight size={200} />
            </div>
            <div className="relative z-10 h-full flex flex-col">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                    <Calendar className="text-blue-300" size={20} /> League Bonuses
                </h3>
                <div className="space-y-3 flex-1 overflow-y-auto pr-2 custom-scrollbar max-h-[150px]">
                    {tasks.filter(t => t.type === 'league').map(task => (
                        <div key={task.id} className="bg-blue-700/50 p-3 rounded-xl border border-blue-500/30 flex justify-between items-center">
                            <div>
                                <h4 className="font-bold text-sm">{task.title}</h4>
                                <div className="mt-1 inline-block bg-white/20 px-2 py-0.5 rounded text-[10px] font-bold">
                                +{task.points} Bonus Pts
                                </div>
                            </div>
                            {task.completed ? <CheckCircle2 size={24} className="text-blue-200"/> : (
                                <button onClick={() => completeTask(task.id, task.points)} className="bg-white text-blue-600 px-3 py-1 rounded-full text-xs font-bold shadow-sm active:scale-95 hover:bg-blue-50">
                                Claim
                                </button>
                            )}
                        </div>
                    ))}
                    <div className="bg-blue-700/30 p-3 rounded-xl border border-blue-500/10 border-dashed text-center">
                        <p className="text-xs font-medium text-blue-200">Complete daily tasks to unlock more bonuses!</p>
                    </div>
                </div>
            </div>
        </div>

      </div>

      {/* Daily Tasks */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-xl text-slate-800 flex items-center gap-2">
            <Flame className="text-orange-500 fill-orange-500" size={24} /> Daily Quests
          </h3>
          <span className="text-xs text-slate-500 font-bold bg-slate-200 px-3 py-1 rounded-full">Reset in 04:12:30</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tasks.filter(t => t.type === 'daily').map(task => (
            <div key={task.id} className={`p-5 rounded-2xl border-2 transition-all hover:shadow-md ${task.completed ? 'border-green-100 bg-green-50' : 'border-slate-100 bg-white shadow-sm'}`}>
              <div className="flex items-start justify-between h-full flex-col">
                <div className="w-full mb-4">
                    <div className="flex justify-between items-start mb-2">
                        <span className={`text-xs font-bold px-2 py-1 rounded-md ${task.completed ? 'bg-green-200 text-green-800' : 'bg-orange-100 text-orange-600'}`}>
                            +{task.points} pts
                        </span>
                        <button 
                            disabled={task.completed}
                            onClick={() => completeTask(task.id, task.points)}
                            className={`transition-colors ${task.completed ? 'text-green-500' : 'text-slate-300 hover:text-green-500'}`}
                        >
                        {task.completed ? <CheckCircle2 size={28} className="fill-green-100" /> : <Circle size={28} />}
                        </button>
                    </div>
                   <h4 className={`font-bold text-lg leading-tight ${task.completed ? 'text-green-800 line-through opacity-70' : 'text-slate-800'}`}>{task.title}</h4>
                   <p className="text-sm text-slate-500 mt-2 leading-snug">{task.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;